<script>
    import { throttle } from "../../scripts/services/actions";
    let windowScrolled = 0;
    let showNav = true;
    let showHideNav = throttle(function(event){
        if(windowScrolled >= window.scrollY || window.scrollY < 70) {
            showNav = true;
        }
        else {
            showNav = false;
        }
        windowScrolled = window.scrollY;
    });
</script>

<a href="#main" class="text-black absolute top-auto left-[-1000px] w-[1px] h-[1px] overflow-hidden z-50">
    Skip To Main Content
</a>
<nav class="header fixed top-0 left-0 w-full bg-white z-30 { showNav ? "translate-y-0" : "hide-navbar"}">
    <div class="flex items-center">
        <h4 class="text-black font-lato text-2xl p-3 font-bold">
            Kanra
        </h4>
        <ul class="list-none flex-auto flex gap-4 items-center content-end p-[4%] md:p-[2%]">
            <ul class="list-none flex items-center flex-auto justify-end invisible gap-14 cursor-pointer lg:visible font-bold font-mono text-lg">
                <li class="hover:opacity-40">
                    Explore
                </li>
                <li class="hover:opacity-40">
                    Packages
                </li>
                <li class="hover:opacity-40">
                    Destinations
                </li>
                <li class="hover:opacity-40">
                    Activities
                </li>
                <li class="hover:opacity-40">
                    About
                </li>
            </ul>
            <li class="lg:flex-1 flex-auto flex justify-end">
                <button class="border-none rounded-full shadow-xl p-2" aria-label="Search Site">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                    </svg>
                </button>
            </li>
        </ul>
    </div>
    <hr class="h-[0.12rem] w-[93%] md:w-full bg-gray-200 mt-[0.15rem] ml-[50%] translate-x-[-50%]">
</nav>

<svelte:window on:scroll="{ showHideNav }"></svelte:window>

<style>
    .header{
        transition: transform 0.2s;
    }
    .hide-navbar{
        transform: translateY(calc(-100% - 1rem));
    }
</style>