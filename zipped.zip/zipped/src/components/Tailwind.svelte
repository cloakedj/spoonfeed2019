<style global>
    @tailwind base;
    @tailwind utilities;
    @tailwind components;
</style>