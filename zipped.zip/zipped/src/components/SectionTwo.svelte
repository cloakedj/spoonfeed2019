<script>
    import Card from "./Card.svelte";
    import { packages } from "../../content/content";
</script>
<h4 class="text-2xl text-black font-lato font-bold mb-3 mt-8 ml-4">
    Packages
</h4>
{#each packages as pkg}
    <Card type="card" pkg={pkg}/>
{/each}