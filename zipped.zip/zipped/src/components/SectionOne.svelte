<script>
    import Card from "./Card.svelte";
    import { destinations } from "../../content/content";
</script>
<section class="lg:flex">
<div class="left lg:flex-auto">
<div class="heading p-6 font-lato flex">
    <h2 class="font-bold text-xl flex-auto">
        We Offer
    </h2>
    <a href="http://goto/ieeol" class="flex items-center gap-1">
        <h3 class="font-bold">Learn More</h3>
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
          </svg>
    </a>
</div>
<div class="flex px-5 gap-2 mb-3 font-lato">
    <div class="rounded-[0.3rem] bg-gradient-to-br from-red-300 to-yellow-400 p-5 text-white flex-auto">
        <h4 class="text-xl mb-0.7 flex items-center gap-0.8">
            <span>5.0</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
        </h4>
        <h6 class="text-sm">
            Customer Rating
        </h6>
        <h4 class="text-xl mt-6">
            180+
        </h4>
        <h6 class="text-sm">
            Monthly Adventures
        </h6>
    </div>
    <div class="rounded-[0.3rem] bg-gradient-to-br from-indigo-300 to-green-400 p-5 text-white flex-auto">
        <h4 class="text-xl mb-0.7">
            2M+
        </h4>
        <h6 class="text-sm">
            Trusting Users
        </h6>
        <h4 class="text-xl mt-6">
            95%
        </h4>
        <h6 class="text-sm">
            Return Customers
        </h6>
    </div>
</div>
</div>
<div class="right">
<h2 class="font-bold text-2xl px-6 py-2 font-lato flex items-center gap-2">
    <span>What Excites You?</span>
</h2>
<ul class="list-none font-lato">
    <li class="flex items-center px-6 py-3 gap-5 cursor-pointer">
        <div class="index">
            <h3 class="h-14 w-14 rounded-full shadow-xl text-2xl p-3 flex items-center justify-center text-white bg-orange-400">D</h3>
        </div>
        <div class="flex flex-col">
            <h4 class="font-bold text-base mb-2">
                Destinations
            </h4>
            <p class="text-sm font-light text-stone-400">
                We offer a variety of destinations as part of our packages.
            </p>
        </div>
    </li>
    <li class="flex items-center px-6 py-3 gap-5 cursor-pointer">
        <div class="index">
            <h3 class="h-14 w-14 rounded-full shadow-xl text-2xl p-3 flex items-center justify-center text-white bg-purple-400">A</h3>
        </div>
        <div class="flex flex-col">
            <h4 class="font-bold text-base mb-2">
                Activities
            </h4>
            <p class="text-sm font-light text-stone-400">
                Perform an excursion for leisure, education or physical purposes!
            </p>
        </div>
    </li>
    <li class="flex items-center px-6 py-3 gap-5 cursor-pointer">
        <div class="index">
            <h3 class="h-14 w-14 rounded-full shadow-xl text-2xl p-3 flex items-center justify-center text-white bg-pink-400">P</h3>
        </div>
        <div class="flex flex-col">
            <h4 class="font-bold text-base mb-2">
                Packages
            </h4>
            <p class="text-sm font-light text-stone-400">
                We offer a ton of packages to select from. Pick anything!
            </p>
        </div>
    </li>
</ul>
</div>
<h4 class="text-2xl text-black font-lato font-bold my-2 ml-4">
    Destinations
</h4>
<section class="p-3">
    {#each destinations as destination}
        <Card type="image" src={destination}/>
    {/each}
</section>
<div class="px-3">
    <button class="group w-full rounded-full bg-indigo-500 p-4 text-white flex items-center justify-center gap-1">
        <span class="uppercase font-bold">All Destinations</span>
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 group-hover:translate-x-1" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clip-rule="evenodd" />
          </svg>
    </button>
</div>
</section>