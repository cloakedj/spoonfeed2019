<script>
  import { fly } from "svelte/transition";
  import { quintOut } from "svelte/easing";
  import { throttle } from "../../scripts/services/actions";
  let showHorizontalContactBtn = true;
  let switchContactBtn = throttle((event) => {
    if (window.scrollY < 100) {
      showHorizontalContactBtn = true;
    } else {
      showHorizontalContactBtn = false;
    }
  });
</script>

<svelte:window on:scroll={switchContactBtn} />

{#if showHorizontalContactBtn}
  <button
    transition:fly={{ easing: quintOut, y: 100 }}
    class="text-white bg-red-500 uppercase fixed bottom-0 w-full p-4 text-xl z-40 flex items-center justify-center gap-2"
    aria-label="Contact Us"
    >
    Contact
    <svg
      xmlns="http://www.w3.org/2000/svg"
      class="h-7 w-7"
      viewBox="0 0 20 20"
      fill="currentColor"
    >
      <path
        d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"
      />
      <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
    </svg>
  </button>
{:else}
  <button
    transition:fly={{ easing: quintOut, x: 100 }}
    class="contact-rounded rounded-full p-4 flex items-center justify-center text-white bg-red-500 z-40 shadow-xl fixed right-2 bottom-2"
    aria-label="Contact Us"
  >
    <svg
      xmlns="http://www.w3.org/2000/svg"
      class="h-9 w-9"
      viewBox="0 0 20 20"
      fill="currentColor"
    >
      <path
        d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"
      />
      <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
    </svg>
  </button>
{/if}
