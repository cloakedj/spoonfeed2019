<script>
    export let type = "";
    export let src = {};
    export let pkg = {};
</script>

<article class="text-white font-lato">
    {#if type === "image"}
        <div class="container mb-7 shadow-lg relative rounded-2xl bg-no-repeat bg-cover bg-center h-full w-full aspect-square overflow-hidden" style="background-image:url('./assets/{src.image}')">
            <div class="absolute z-20 p-8 w-full bottom-0">
                <h2 class="text-2xl font-bold mb-1 flex items-center gap-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                   {src.destination}
                </h2>
                <p class="text-sm">
                    {src.tagline}
                </p>
            </div>
            <div class="mask z-10 absolute top-0 left-0 bg-[#00000085] h-full w-full backdrop-blur-[1.5px]"></div>
        </div>
    {/if}
    {#if type === "card"}
        <img src="./assets/{pkg.image}" class="aspect-square w-[91%] rounded-xl shadow-xl ml-[50%] translate-x-[-50%] mt-4" alt={pkg.imageAlt}>
        <h2 class="text-indigo-800 px-5 pt-5">
            <span class="text-xl font-bold uppercase">
                {pkg.title}
            </span>
            <h3 class="flex items-center gap-1 mt-1">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                </svg>
                {pkg.location}
            </h3>
         </h2>
         <h4 class="text-lg text-slate-400 flex items-center gap-1 px-5 mt-5 mb-2 capitalize">
            About the trip 
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM4.332 8.027a6.012 6.012 0 011.912-2.706C6.512 5.73 6.974 6 7.5 6A1.5 1.5 0 019 7.5V8a2 2 0 004 0 2 2 0 011.523-1.943A5.977 5.977 0 0116 10c0 .34-.028.675-.083 1H15a2 2 0 00-2 2v2.197A5.973 5.973 0 0110 16v-2a2 2 0 00-2-2 2 2 0 01-2-2 2 2 0 00-1.668-1.973z" clip-rule="evenodd" />
              </svg>
        </h4>
         <p class="text-black px-5">
            {pkg.description}...
         </p>
         <div class="flex items-center p-5">
            <h6 class="w-[50%] text-slate-900 text-base flex items-center justify-center gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 8h6m-5 0a3 3 0 110 6H9l3 3m-3-6h6m6 1a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                {pkg.price} / Per {pkg.per}.
            </h6>
            <a href={pkg.target} class="w-[50%]">
                <button class="w-full bg-orange-500 text-lg text-white rounded-md p-4 flex items-center gap-2 justify-center" aria-label="More Info">
                    <span>More Info</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </button>
            </a>
        </div>
    {/if}
</article>