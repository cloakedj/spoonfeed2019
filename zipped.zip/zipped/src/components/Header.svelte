<script>
  import Nav from "./Nav.svelte";
</script>

<Nav />

<section class="mt-[20%] p-3 font-lato">
  <h1 class="text-[2.7rem] text-black font-bold">
    Life is either a daring adventure or nothing!
  </h1>
  <p class="text-lg mt-1">
    The way up to the top of the mountain is always longer than you think. Don't
    fool yourself.
  </p>
</section>
<div class="clip-container">
    <img
        src="./assets/boat-mountain.jpg"
        class="w-full scale-[0.85] rotate-[8deg] rounded-xl"
        alt="A beautiful road with yellow centered stripes surrounded by mountains."
    />
    <img
    src="./assets/travel-bg.jpg"
    class="w-full scale-[0.78] rotate-[-5deg] rounded-xl mt-[-25%]"
    alt="A beautiful road with yellow centered stripes surrounded by mountains."
    />
    <img
    src="./assets/shadow.jpg"
    class="w-full scale-[0.78] rotate-[12deg] rounded-xl mt-[-60%]"
    alt="A beautiful road with yellow centered stripes surrounded by mountains."
    />
</div>
<button class="bg-white font-lato uppercase text-sm shadow-2xl rounded-md px-9 py-4 absolute bottom-2 left-[50%] font-bold translate-x-[-50%]">
    Join Now
</button>

<style>
  .clip-container {
    clip-path: ellipse(200% 88% at 70% 90%);
    @apply bg-gradient-to-b from-indigo-300 to-orange-300;
  }
</style>
