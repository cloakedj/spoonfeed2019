<script>
    import Tailwind from "./components/Tailwind.svelte";
    import Header from "./components/Header.svelte";
    import SectionOne from "./components/SectionOne.svelte";
    import SectionTwo from "./components/SectionTwo.svelte";
    import Contact from "./components/Contact.svelte";
</script>

<Header />
<main id="main">
    <SectionOne />
    <SectionTwo />
</main>
<Contact />