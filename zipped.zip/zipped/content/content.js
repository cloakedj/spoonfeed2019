export const destinations = [
    {
        id: 1,
        destination: "Shimla",
        tagline: "Shimla is one of the most beautiful cities of Northern India. Incredible Himachal!",
        image: "beach.jpg"
    }, 
    {
        id: 2,
        destination: "Kasauli",
        tagline: "Kasauli is one of the most beautiful cities of Northern India. Incredible Himachal!",
        image: "boat-mountain.jpg"
    },
    {
        id: 3,
        destination: "Kullu Manali",
        tagline: "Kullu Manali is one of the most beautiful cities of Northern India. Incredible Himachal!",
        image: "destination.jpg"
    },
    {
        id: 4,
        destination: "Chamba",
        tagline: "Chamba is one of the most beautiful cities of Northern India. Incredible Himachal!",
        image: "lake.jpg"
    }
];

export const packages = [
    {
        id: 1,
        title: "Mountain Safari",
        location: "Kolkata, India",
        description: "List of inspiring slogans a fresh coat for a fresh start meet the world make traveling fun explore, globe with a new sky, a new life let us help you find",
        price: "6000",
        per: "day",
        target: "http://goto/ieeol",
        image: "beach.jpg",
        imageAlt: "A beautiful beach in sun."
    },
    {
        id: 2,
        title: "Mountain Safari",
        location: "Kolkata, India",
        description: "List of inspiring slogans a fresh coat for a fresh start meet the world make traveling fun explore, globe with a new sky, a new life let us help you find",
        price: "12000",
        per: "day",
        target: "http://goto/ieeol",
        image: "lake.jpg",
        imageAlt: "A beautiful beach in sun."
    },
    {
        id: 3,
        title: "Mountain Safari",
        location: "Kolkata, India",
        description: "List of inspiring slogans a fresh coat for a fresh start meet the world make traveling fun explore, globe with a new sky, a new life let us help you find",
        price: "50000",
        per: "day",
        target: "http://goto/ieeol",
        image: "travel-bg.jpg",
        imageAlt: "A beautiful beach in sun."
    }
];