export function throttle(func){
    let ticking = false;
    return function accelerate(){
        let context = this;
        let args = arguments;
        if(!ticking){
            window.requestAnimationFrame(function(){
                func.apply(context, args)
                ticking = false;
            });
            ticking = true;
        }
    }
}